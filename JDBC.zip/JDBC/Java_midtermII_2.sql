create database products

CREATE TABLE products (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    price_per_unit DOUBLE,
    active_for_sell BOOLEAN
);
go
INSERT INTO Product (id, name, price_per_unit, active_for_sell) VALUES
(1, 'Coke', 2.00, true),
(2, 'Pepsi', 2.00, true),
(3, 'Kizz', 1.50, true),
(4, 'Redbull', 2.00, true);
